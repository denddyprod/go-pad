package main

import (
	"flag"
	"gochat/controllers"
	"gochat/models"
	"gochat/websocket"
	"log"
	"net/http"

	"time"

	"github.com/gorilla/mux"
)

var addr = flag.String("addr", ":8080", "http service address")

func main() {
	flag.Parse()

	hub := websocket.NewHub()

	go hub.Run()

	// Initiate models
	padModel := models.NewPadModel()

	// Initiate controllers
	padController := controllers.NewPadController(padModel)

	router := mux.NewRouter().StrictSlash(true)
	router.Handle("/favicon.ico", http.StripPrefix("/", http.FileServer(http.Dir("./public/"))))
	router.Handle("/js/{name}", http.StripPrefix("/js/", http.FileServer(http.Dir("./public/js/"))))
	router.Handle("/css/{name}", http.StripPrefix("/css/", http.FileServer(http.Dir("./public/css/"))))
	router.HandleFunc("/ws/{name}", func(w http.ResponseWriter, r *http.Request) { websocket.ServeWs(hub, w, r) })
	router.HandleFunc("/", padController.ServeHome).Methods(http.MethodGet)
	router.HandleFunc("/{name}", padController.ServePad).Methods(http.MethodGet)

	server := &http.Server{
		ReadTimeout:  5 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  120 * time.Second,
		Handler:      router,
		Addr:         *addr,
	}

	log.Println("Starting backend application on " + *addr)
	log.Fatal(server.ListenAndServe())
}

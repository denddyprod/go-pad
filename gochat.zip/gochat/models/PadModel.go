package models

type PadModel struct {
}

func NewPadModel() *PadModel {
	return &PadModel{}
}
